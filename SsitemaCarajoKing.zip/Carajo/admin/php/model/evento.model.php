<?php
include '../util/util2.php';

class eventoModel {

    private $cn;

    function __construct(){
      $db_cone = new util();
      $this->cn = $db_cone->getConexion();
    }

    public function lisEven(){/*PARA LISTAR LOS PRODUCTOS*/ /*lisprod*/
        $res=$this->cn->prepare('call mostEvent()');/*LLAMAMOS LA PROCEDIMIENTO*/
        $res->execute();
        return $res->fetchAll(PDO::FETCH_OBJ);//return $res->fetchAll(PDO::FETCH_OBJ);/*TE TRAE POR EL NOMBRE DE LA COLUMNA*/
    }

    public function elimEvent($id){/*FUNCION PARA BORRAR*//*elimicli*/
        $res=$this->cn->prepare("call borraEvent(?)");/*LLAMAMOS AL PROCEDIMIENTO*//*eliminaclient*/
        $res->execute(array($id));      
    }

    public function editEvent($data){/*PARA INSERTAR LOS PRODUCTOS*/ /*insertProd*/
        $res=$this->cn->prepare("call editaEvent(?,?,?,?,?,?)");/*AQUI ESTOY LLAMANDO AL PROCEDIMIENTO: INSERTAR PRODUCTOS, ENVIANDO DE PARAMETROS TITU Y CUER*/       
        $res->execute($data);
        return $res->fetchAll(PDO::FETCH_OBJ);
    }

    public function insertEvent($data){/*PARA INSERTAR LOS PRODUCTOS*/ /*insertProd*/
        $res=$this->cn->prepare("call insertEvent(?,?,?,?,?)");/*AQUI ESTOY LLAMANDO AL PROCEDIMIENTO: INSERTAR PRODUCTOS, ENVIANDO DE PARAMETROS TITU Y CUER*/
        $res->execute($data); 
        $ruta="../../../img/evento/";
        $img1 = @$_FILES['foto']['tmp_name'];    
        $img2 = @$_FILES['foto2']['tmp_name'];    
        $img3 = @$_FILES['foto3']['tmp_name'];    
        $img4 = @$_FILES['foto4']['tmp_name'];
        foreach ($res as $row) {
            $nomimg1 = $row[1];
            $nomimg2 = $row[2];
            $nomimg3 = $row[3];
            $nomimg4 = $row[4];
            
            move_uploaded_file($img1, $ruta . "/" . $nomimg1);
            move_uploaded_file($img2, $ruta . "/" . $nomimg2);
            move_uploaded_file($img3, $ruta . "/" . $nomimg3);
            move_uploaded_file($img4, $ruta . "/" . $nomimg4);
        }
        return $res->fetchAll(PDO::FETCH_OBJ);
    }
}
?>
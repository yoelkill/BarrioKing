<?php
include '../util/util2.php';

class sliderModel {

    private $cn;

    function __construct(){
      $db_cone = new util();
      $this->cn = $db_cone->getConexion();
    }

    public function lisSlider(){
        $res=$this->cn->prepare('call mostSlider()');
        $res->execute();
        return $res->fetchAll(PDO::FETCH_OBJ);
    }

    public function elimSlider($id){
        $res=$this->cn->prepare("call borraSlider(?)");
        $res->execute(array($id));      
    }

    public function editaSlider($data){
        $res=$this->cn->prepare("call editaSlider(?,?,?)");
        $res->execute($data);
        return $res->fetchAll(PDO::FETCH_OBJ);
    }

    public function insertslider($data){
        $res=$this->cn->prepare("call insertSli(?,?)");
        $res->execute($data); 
        return $res->fetchAll(PDO::FETCH_OBJ);
    }
}
?>
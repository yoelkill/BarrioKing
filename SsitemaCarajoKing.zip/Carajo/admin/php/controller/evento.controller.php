<?php
session_start();
include '../model/evento.model.php';

if (isset($_REQUEST['op'])){
    $accion = $_REQUEST['op'];
    $controller = new eventoController();
    call_user_func(array($controller,$accion));
}


class eventoController
{

    private $model;

    function __construct()
    {
        $this->model = new eventoModel();  
    }

    function __call($method,$args){
        if (method_exists($this, $method) ){
            call_user_func(array($this,$method),$args);
        }else{
            header('Location: index.php');
        }
    }

    function listar(){
        echo json_encode($this->model->lisEven());/*LLAMAS A LA FUNCION LISTAR SERVICIOS Y lo imprime en formato json*/ 
    }

    function eliminar(){
        $id = $_REQUEST['id'];
        $this->model->elimEvent($id);/*LLAMAS A LA FUNCION PARA ELIMINAR*/
        unlink("../../../img/evento/".$id.'.jpg');
        unlink("../../../img/evento/".$id.'b.jpg');
        unlink("../../../img/evento/".$id.'c.jpg');
        unlink("../../../img/evento/".$id.'d.jpg');
        echo json_encode("OK");
    }

    function editar(){

        $data = array();
        $data[] = $_REQUEST['cod'];
        $data[] = $_REQUEST['titu'];
        $data[] = $_REQUEST['lug'];
        $data[] = $_REQUEST['fec_i'];
        $data[] = $_REQUEST['est'];
        $data[] = $_REQUEST['cuerpo'];

        $id = $this->model->editEvent($data);

        $ruta="../../../img/evento/";
        
        $archivo1 = @$_FILES['foto']['tmp_name'];
        $archivo2 = @$_FILES['foto2']['tmp_name'];       
        $archivo3 = @$_FILES['foto3']['tmp_name'];       
        $archivo4 = @$_FILES['foto4']['tmp_name'];

        $nom_archivo1 = @$_FILES['foto']['name'];
        $nom_archivo2 = @$_FILES['foto2']['name'];
        $nom_archivo3 = @$_FILES['foto3']['name'];
        $nom_archivo4 = @$_FILES['foto4']['name'];

        $ext1 = pathinfo($nom_archivo1);
        $ext2 = pathinfo($nom_archivo2);
        $ext3 = pathinfo($nom_archivo3);
        $ext4 = pathinfo($nom_archivo4);

        move_uploaded_file($archivo1, $ruta . "/" . $data[0] . "." . @$ext1['extension']);
        move_uploaded_file($archivo2, $ruta . "/" . $data[0] . "b." . @$ext2['extension']);
        move_uploaded_file($archivo3, $ruta . "/" . $data[0] . "c." . @$ext3['extension']);
        move_uploaded_file($archivo4, $ruta . "/" . $data[0] . "d." . @$ext4['extension']);
        
        echo json_encode('OK');
    }

    function insertar(){
        
        $data = array();      
        $data[] = $_REQUEST['titu'];
        $data[] = $_REQUEST['lug'];   
        $data[] = $_REQUEST['fec_i'];
        $data[] = $_REQUEST['est'];
        $data[] = $_REQUEST['cuerpo'];

        $name = $this->model->insertEvent($data);
        echo json_encode('OK');
    }
}
jQuery(document).ready(function() {
ListaEvento();    
        
    var date_i = "";
    date_picker();
        
    
         
});

$("#formevent").validate({	 /*<<<<<<<<<*/   	 
		submitHandler: function(form) {	
			CKupdate();
			var formData = new FormData($(form)[0]);
			formData.append("fec_i", date_i);
			console.log(date_i);	
			var fun;
			if ($('#cod').val() == ''){
				fun = 'insertar'
			}else{
				fun = 'editar'
			}

			$.ajax({
                url: 'php/controller/evento.controller.php?op='+fun,
                type: 'POST',
                async: false,
    			cache: false,
    			contentType: false,
    			processData: false,
				dataType: 'json',
				data: formData,
				success: function(){
 					swal("Registro insertado!", "", "success");
 					ListaEvento();
 					ocultaformulario();
 					$('#formevent')[0].reset(); /*<<<<<<<<<*/  
				}
			}).fail(function() {
 				//console.log(objeto);
 				sweetAlert("Error", "No se pudo agregar!", "error");
			}); 
		}
	});

function date_picker(i) {
    
    if (i != undefined) {
        date_i = i;
        var ini = new Date(i);
        console.log(ini);
        $('#cfec_i').bootstrapMaterialDatePicker('setDate', ini);
    } else {
        $('#cfec_i').bootstrapMaterialDatePicker({
            format: 'DD-MM-YYYY HH:mm',
            lang: 'es',
            cancelText: 'CANCELAR',
            okText: 'ACEPTAR'
        }).on("change", function(e, d) {
            var date = new Date(d._d);
            console.log(d);
            date_i = date.getFullYear() + '-' + 
            (date.getMonth() < 10 ? '0' : '') + date.getMonth() + '-' + 
            (date.getDate() < 10 ? '0' : '') + date.getDate() + ' ' + 
            (date.getHours() < 10 ? '0' : '') + date.getHours() + ':' + 
            (date.getMinutes() < 10 ? '0' : '') + date.getMinutes();
            console.log(date_i);
        }
        );
    }
}

function ListaEvento(){
	var oTable = $('#evento').dataTable();
 
	var oElim = {
			op: 'listar'
	}

	var btn_hea = '<button class="btn btn btn-primary"  id="Edita_';
	var btn_foo = '">   Editar</button>';

	var btn_hea_e = '<button class="btn btn btn-danger" name="Eliminar" value="';
	var btn_foo_e = '" onclick="btnElimina(this);">   Eliminar</button>';

		$.ajax({
		url: 'php/controller/evento.controller.php',
		data: oElim,
		dataType: 'json',
		success: function(json){
			oTable.fnClearTable();
			$.each(json, function(index,objeto){
				oTable.fnAddData([
					objeto.eve_titulo,
					objeto.eve_lugar,
					objeto.eve_fecha,
					objeto.eve_estado,
					objeto.eve_cuerpo,
					'<img width="150px" src="../img/evento/' + objeto.eve_foto1 + '">',
					'<img width="150px" src="../img/evento/' + objeto.eve_foto2 + '">',
					'<img width="150px" src="../img/evento/' + objeto.eve_foto3 + '">',
					'<img width="150px" src="../img/evento/' + objeto.eve_foto4 + '">',
					btn_hea + objeto.eve_cod + btn_foo +btn_hea_e + objeto.eve_cod + btn_foo_e
				]);
				$('#Edita_'+objeto.eve_cod).data('datos',objeto);
				$('#Edita_'+objeto.eve_cod).click(function(){
					var objeto = $(this).data('datos');
					$('#cod').val(objeto.eve_cod);
					$('#nom_tit').val(objeto.eve_titulo);
					$('#nom_lug').val(objeto.eve_lugar);
					$('#nom_est').val(objeto.eve_estado);
					date_picker(objeto.eve_fecha2);
					console.log(objeto.eve_fecha2);
					//$('#nom_cue').val(objeto.eve_cuerpo);
					CKEDITOR.instances['nom_cue'].setData(objeto.eve_cuerpo);
					//console.log(objeto.eve_titulo, objeto.eve_lugar, objeto.eve_fecha, objeto.eve_cuerpo);
					muestraformulario2();
				});	
			});
		}
		}).fail(function() {
			sweetAlert("Error", "No se pudo Listar!", "error");
	    });
};

 
function btnElimina(boton){
		swal({   
		   title: "Esta seguro de elimiar este Evento?",
		   text: "",
		   type: "warning",
		   showCancelButton: true,
		   confirmButtonColor: "#DD6B55",
		   confirmButtonText: "Si, eliminarlo!",   
		   closeOnConfirm: false 
		},
		function(){  
		  	var row = $(boton).closest("tr").get(0);
			var rowE = $(boton).closest("tr");
			var cod = $(boton).attr("value");
			var oElim = {
				id: cod,
				op: 'eliminar'
			}
            console.log(oElim);
		    $.ajax({
		        type: 'POST',
		        url: 'php/controller/evento.controller.php',
		        data: oElim,
		        dataType: 'json',
		        success: function() {
		   			rowE.fadeOut(750,function(){
			  		var dtable = $('#evento').dataTable();
					var Pos = dtable.fnGetPosition(row);
					dtable.fnDeleteRow(Pos);
					});
		   			swal("Eliminado!", "Registro eliminado con exito.", "success");
		        }
		    }).fail(function() {    
				sweetAlert("Error", "No se pudo eliminar!", "error");
		    });
	})
}

$('#formulariohide').hide();

function muestraformulario(){
    $('#formulariohide').fadeIn(500);
    $('#formevent')[0].reset(); /*<<<<<<<<<*/   
    CKEDITOR.instances['nom_cue'].setData('');
    $("body").animate({
      scrollTop: 2000
    }, 1000);
}

function muestraformulario2(){
    $('#formulariohide').fadeIn(500);
    $("body").animate({
      scrollTop: 2000
    }, 1000);
}

function ocultaformulario(){
    $('#formulariohide').fadeOut(500);
    $('#formevent')[0].reset(); 
}

function nuevo(){
	$('#cod').val('');
}

function CKupdate(){
	for (instance in CKEDITOR.instances) {
		CKEDITOR.instances[instance].updateElement();
	};
}



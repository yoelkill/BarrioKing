

<?php

session_start();
include_once 'php/util/dbconnect.php';
/*$con = mysql_connect("localhost", "root", "");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
$db_selected = mysql_select_db("carajo",$con);

// check for form submission - if it doesn't exist then send back to contact form
// if (!isset($_POST['save']) || $_POST['save'] != 'contact') {
//     header('Location: reservaciones.php'); exit;
// }*/

$res=mysql_query("SELECT * FROM users WHERE user_id=".$_SESSION['user']);
    $userRow=mysql_fetch_array($res);
// get the posted data
 //$userRow['user_name'];


$doj = $_POST['date'] ;
$name = strip_tags( utf8_decode( $_POST['user_name'] ) );
$userid = $userRow['user_id'];
$usermail = $userRow['user_email'];



//$email = strip_tags( utf8_decode( $_POST['user_email'] ) );
	
// check that name was entered
if (empty($name))
    $error = 'Coloca tu Nombre.';


// check that user id was entered


// check that an email address was entered
// elseif (empty($email)) 
//     $error = 'You must enter your email address.';
// // check for a valid email address
// elseif (!preg_match('/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/', $email))
//     $error = 'You must enter a valid email address.';



/*
//Check whether the student is already registered.
$select = mysql_query("select * from users where user_id = '".$userRow['userid']."'", $con);

//$query = mysql_real_escape_string($select);

$num_rows = mysql_num_rows($select);

if ( $num_rows )
	$error = 'You are already registered.';
	
	
// check if an error was found - if there was, send the user back to the form
if (isset($error)) {
    header('Location: book.php?e='.urlencode($error)); exit;
}



// Success
$query = "INSERT INTO users (user_id, user_name,user_email, user_pass) VALUES ('" . $userid . "','" . $name . "','" . $email . "','" . $password . "')";

$insert = mysql_real_escape_string($query);

$results = mysql_query($query);

if (!$results)
{
	die ("Could not insert to the register: <br />". mysql_error());
}
*/
$seatNumber = NULL;

for($i=1; $i<11; $i++)
{
	$chparam = "ch" . strval($i);
	$calcPNR = $_POST['date']. "-" .strval($i);
	if( !empty($_POST[$chparam]) )
	{
		echo $doj;
		$query = "INSERT INTO seat VALUES ('".$userid."', '" . intval($i) . "', '". $calcPNR ."', '".$_POST['date']."')";
//		$results = mysql_real_escape_string($query);
		$results = mysql_query($query);
		if (!$results)
		{
			die ("No puede Usar los Asientos: <br />". mysql_error());
		}
		$seatNumber = $seatNumber .", ". "$i";
	}
}
if(!empty($message))
{
	$message = "El Usuario  ". $name ."  Reservo Los Asientos : ". $seatNumber ;	
}
else
{
	$message = "El Usuario  ". $name ."  Reservo Los Asientos : ". $seatNumber;	
}
 
?>

 <?php
// write the email content
$email_content = "Nombre: $name\n";
$email_content.= "Email : ".$usermail."\n";
$email_content.= "Mensaje:\n\n$message";
$email_content.= "";



$messageUser = "Tu Ticket ha Sido Reservado Para El siguinete Asiento: " . $seatNumber;
	
// send the email
mail ("jeralbenites@gmail.com", "Reservacion De Asiento", $email_content);
mail ($usermail, "Reserva de asiento Cliente ", $messageUser);

/*$my_file = "tuarchivo.png"; // puede ser cualquier formato
$my_path = $_SERVER['DOCUMENT_ROOT']."/ruta_a_tu_archivo/";
$my_name = "Tu nombre";
$my_mail = "tumail@tudominio.com";
$my_replyto = "tumail@tudominio.com";
$my_subject = "Le adjuntamos la credencial de invuitación al evento";
$my_message = "Tu mensaje";
mail_attachment($my_file, $my_path, "casilla_destinatario@dominio.com", $my_mail, $my_name, $my_replyto, $my_subject, $my_message);*/
mysql_close($connection);	
// send the user back to the form

header('Location: book.php?s='.urlencode('Tu Asiento esta Reservado.')); exit;

?>


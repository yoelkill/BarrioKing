<?php 
	require_once 'php/controller/web.controller.php';
	$controller = new webController();
	$lista_eventoActivo = call_user_func(array($controller,'lista_eventoActivo'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<title>Eventos del Carajo</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<!-- SLIDE -->
	<link rel="stylesheet" type="text/css" href="css/navstylechange.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="css/settings.css" media="screen" />
	<!-- NAVBAR & LOGIN -->
	<link rel="stylesheet" href="css/navbar.css">
	<!-- JQUERY -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
</head>
<body style="background:black;">
	<?php include("php/layout/navbar.php"); ?>
	
	<?php include("php/layout/slider.php"); ?>

	
	<h1 class="text-center" style="color:white;">Eventos</h1>
	<br>

	<div class="container">
		<div class="row">
			<?php foreach ($lista_eventoActivo as $row) { ?>
			<div class="col-sm-6 col-md-4">
				<div class="panel panel-danger"> 
					<div class="panel-heading"> 
						<h3 class="panel-title"><?php echo $row->eve_titulo?></h3> 
					</div> 
					<div class="panel-body">
						<img class="img-responsive" src="img/evento/<?php echo $row->eve_foto1?>" alt="...">
						<br>
						<a href="detalle.php?pro=<?php echo $row->eve_cod ?>" class="btn btn-danger btn-lg btn-block" role="button">Ver Más</a>
					</div> 
				</div>
			</div>
			<?php } ?>			
		</div>
	</div>
	<script src="js/bootstrap.min.js"></script>
	<!-- SLIDER REVOLUTION 4.x SCRIPTS  -->
    <script type="text/javascript" src="js/jquery.themepunch.tools.min.js"></script>
    <script type="text/javascript" src="js/jquery.themepunch.revolution.min.js"></script>
    <!-- LOGIN -->
    <script src="js/login.js"></script>
</body>
</html>
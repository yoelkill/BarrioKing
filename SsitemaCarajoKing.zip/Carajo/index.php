<?php
session_start();
if(isset($_SESSION['user'])!="")
{
	header("Location: home.php");
}
include_once 'php/util/dbconnect.php';

if(isset($_POST['btn-signup']))
{
	$uname = mysql_real_escape_string($_POST['uname']);
	$email = mysql_real_escape_string($_POST['email']);
	$upass = md5(mysql_real_escape_string($_POST['pass']));
	
	$uname = trim($uname);
	$email = trim($email);
	$upass = trim($upass);
	
	// email exist or not
	$query = "SELECT user_email FROM users WHERE user_email='$email'";
	$result = mysql_query($query);
	
	$count = mysql_num_rows($result); // if email not found then register
	
	if($count == 0){
		
		if(mysql_query("INSERT INTO users(user_name,user_email,user_pass) VALUES('$uname','$email','$upass')"))
		{
			?>
			<script>alert('Registro existoso ');</script>
			<?php
		}
		else
		{
			?>
			<script>alert('Error al registrarse...');</script>
			<?php
		}		
	}
	else{
			?>
			<script>alert('Lo sentimos ese correo ya esta en uso ...');</script>
			<?php
	}
	
}
?>
<?php 
	require_once 'php/controller/web.controller.php';
	$controller = new webController();
	$lista_evento = call_user_func(array($controller,'lista_evento'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<title>Eventos del Carajo</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<!-- SLIDE -->
	<link rel="stylesheet" type="text/css" href="css/navstylechange.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="css/settings.css" media="screen" />
	<!-- NAVBAR & LOGIN -->
	<link rel="stylesheet" href="css/login.css">
	<!-- JQUERY -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
</head>
<body style="background:black;">

	<?php include("php/layout/login.php"); ?>
	
	<div class="container">
		<div class="row">
			<div class="col-xs-12 col-sm-12 col-md-12">
				<img class="img-responsive center-block" src="img/logo/logo.png" alt="">
			</div>
		</div>
	</div>

	<br><br>

	<div class="container">
		<div class="row">
			<?php foreach ($lista_evento as $row) { ?>
			<div class="col-sm-6 col-md-4">
				<div class="panel panel-danger"> 
					<div class="panel-heading"> 
						<h3 class="panel-title"><?php echo $row->eve_titulo?></h3> 
					</div> 
					<div class="panel-body">
						<img class="img-responsive" src="img/evento/<?php echo $row->eve_foto1?>" alt="...">						
					</div> 
				</div>
			</div>
			<?php } ?>			
		</div>
	</div>
	
	<script src="js/bootstrap.min.js"></script>
	<!-- SLIDER REVOLUTION 4.x SCRIPTS  -->
    <script type="text/javascript" src="js/jquery.themepunch.tools.min.js"></script>
    <script type="text/javascript" src="js/jquery.themepunch.revolution.min.js"></script>
    <!-- LOGIN -->
    
    
</body>
</html>
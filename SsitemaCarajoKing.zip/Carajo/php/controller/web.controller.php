<?php 
require_once 'php/model/web.model.php';

class webController 
{
	private $model;

	function __construct()
	{
		$this->model = new webModel();
	}
	
	/*----------------------------------*/
	function lista_slider(){
		return $this->model->lista_slider();
	}
	function lista_evento(){
		return $this->model->lista_evento();
	}	
	function lista_eventoActivo(){
		return $this->model->lista_eventoActivo();
	}	
	function lista_detalle($cod){
		return $this->model->lista_detalle($cod);
	}
}

<?php 
require_once 'php/util/util.php';

class webModel
{

	private $cn;
	
	function __construct()
	{
		$db_cone = new util();
		$this->cn = $db_cone->getConexion();

	}

	/*----------------------------------*/
	function lista_slider(){
		$res = $this->cn->prepare('call mostSlider()');
		$res->execute();
		return $res->fetchAll(PDO::FETCH_OBJ);
	}
	
	function lista_evento(){
		$res = $this->cn->prepare('call mostEvent()');
		$res->execute();
		return $res->fetchAll(PDO::FETCH_OBJ);
	}

	function lista_eventoActivo(){
		$res = $this->cn->prepare('call mostEventAct()');
		$res->execute();
		return $res->fetchAll(PDO::FETCH_OBJ);
	}

	function lista_detalle($cod){
		$res = $this->cn->prepare('call mostEventDetalle(?)');
		$res->execute(array($cod));
		return $res->fetchAll(PDO::FETCH_OBJ);
	}
	

}
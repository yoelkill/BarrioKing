<?php 
  require_once 'php/controller/web.controller.php';
  $controller = new webController();
  $lista_eventoActivo = call_user_func(array($controller,'lista_eventoActivo'));
?>
<article class="boxedcontainer">

  <div class="tp-banner-container">
    <div class="tp-banner" >
      <ul>        
        <?php foreach ($lista_eventoActivo as $row ) { ?>         
          <li data-transition="zoomin" data-slotamount="7" data-masterspeed="600" >
            <img src="img/evento/<?php echo $row->eve_foto1?>"  alt="videobg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">          
          </li>
          <li data-transition="zoomin" data-slotamount="7" data-masterspeed="600" >
            <img src="img/evento/<?php echo $row->eve_foto2?>"  alt="videobg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">          
          </li>
          <li data-transition="zoomin" data-slotamount="7" data-masterspeed="600" >
            <img src="img/evento/<?php echo $row->eve_foto3?>"  alt="videobg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">          
          </li>
        <?php } ?>
      </ul>
      <div class="tp-bannertimer"></div>
    </div>
  </div>
  
  <script type="text/javascript">

    var revapi;

    jQuery(document).ready(function() {

         revapi = jQuery('.tp-banner').revolution(
        {
          delay:9000,
          startwidth:1170,
          startheight:400,
          hideThumbs:10,
          fullWidth:"on",
          forceFullWidth:"on"
        });

    }); //ready

  </script>

  <!-- END REVOLUTION SLIDER -->

</article><!-- Content End -->
<?php 
  require_once 'php/controller/web.controller.php';
  $controller = new webController();
  $lista_slider = call_user_func(array($controller,'lista_slider'));
?>
<article class="boxedcontainer">

  <div class="tp-banner-container">
    <div class="tp-banner" >
      <ul>        
        <?php foreach ($lista_slider as $row ) { ?>         
        <li data-transition="zoomin" data-slotamount="7" data-masterspeed="600" >
          <img src="img/slider/<?php echo $row->sli_foto?>"  alt="videobg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">          
        </li>
        <?php } ?>
      </ul>
      <div class="tp-bannertimer"></div>
    </div>
  </div>
  
  <script type="text/javascript">

    var revapi;

    jQuery(document).ready(function() {

         revapi = jQuery('.tp-banner').revolution(
        {
          delay:9000,
          startwidth:1170,
          startheight:400,
          hideThumbs:10,
          fullWidth:"on",
          forceFullWidth:"on"
        });

    }); //ready

  </script>

  <!-- END REVOLUTION SLIDER -->

</article><!-- Content End -->
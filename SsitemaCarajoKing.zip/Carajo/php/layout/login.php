<?php
session_start();
include_once 'php/util/dbconnect.php';

if(isset($_SESSION['user'])!="")
{
    header("Location: home.php");
}

if(isset($_POST['btn-login']))
{
    $email = mysql_real_escape_string($_POST['email']);
    $upass = mysql_real_escape_string($_POST['pass']);
    
    $email = trim($email);
    $upass = trim($upass);
    
    $res=mysql_query("SELECT user_id, user_name, user_pass FROM users WHERE user_email='$email'");
    $row=mysql_fetch_array($res);
    
    $count = mysql_num_rows($res); // if uname/pass correct it returns must be 1 row
    
    if($count == 1 && $row['user_pass']==md5($upass))
    {
        $_SESSION['user'] = $row['user_id'];
        header("Location: home.php");
    }
    else
    {
        ?>
        <script>alert('Usuario / Contraseña incorrectas o no existen !');</script>
        <?php
    }
    
}
?>
<link href="http://cdn.phpoll.com/css/animate.css" rel="stylesheet">
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container-fluid">
            <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
                <a class="navbar-brand" href="">Peña el Carajo</a>
            </div>
            <div id="navbar" class="collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <li class="active"><a href="">Home</a></li>
                    <li><a href="">About</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a href="" class="dropdown-toggle" data-toggle="dropdown">Registrar <span class="caret"></span></a>
                        <ul class="dropdown-menu dropdown-lr animated flipInX" role="menu">
                            <div class="col-lg-12">
                                <div class="text-center"><h3><b>Registrar</b></h3></div>
                                <form id="registrarUser" method="post" role="form" autocomplete="off">
                                    <div class="form-group">
                                        <input type="text" name="uname" id="username" tabindex="1" class="form-control" placeholder="Nombre Usuario" value="">
                                    </div>
                                    <div class="form-group">
                                        <input type="email" name="email" id="email" tabindex="1" class="form-control" placeholder="Correo Electronico" value="">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" name="pass" id="password" tabindex="2" class="form-control" placeholder="Contraseña">
                                    </div>
                                    <!-- <div class="form-group">
                                        <input type="password" name="confirm-password" id="confirm-password" tabindex="2" class="form-control" placeholder="Confirmar Contraseña">
                                    </div> -->
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-xs-6 col-xs-offset-3">
                                                <input type="submit" name="btn-signup" id="register-submit" tabindex="4" class="form-control btn btn-info" value="Registrar Ahora">
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" class="hide" name="token" id="token" value="7c6f19960d63f53fcd05c3e0cbc434c0">
                                </form>
                            </div>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="" class="dropdown-toggle" data-toggle="dropdown">Inicio Sesion <span class="caret"></span></a>
                        <ul class="dropdown-menu dropdown-lr animated slideInRight" role="menu">
                            <div class="col-lg-12">
                                <div class="text-center"><h3><b>Iniciar</b></h3></div>
                                <form id="ajax-login-form" action="" method="post" role="form" autocomplete="off">
                                    <div class="form-group">
                                        <label for="username">Correo Electronico</label>
                                        <input type="text" name="email" id="username" tabindex="1" class="form-control" placeholder="Email" value="" autocomplete="off">
                                    </div>

                                    <div class="form-group">
                                        <label for="password">Contraseña</label>
                                        <input type="password" name="pass" id="password" tabindex="2" class="form-control" placeholder="Contraseña" autocomplete="off">
                                    </div>

                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-xs-7">
                                                <input type="checkbox" tabindex="3" name="remember" id="remember">
                                                <label for="remember"> Recordar</label>
                                            </div>
                                            <div class="col-xs-5 pull-right">
                                                <input type="submit" name="btn-login" id="login-submit" tabindex="4" class="form-control btn btn-success" value="Iniciar" onclick="location.href='logeo.php';">
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" class="hide" name="token" id="token" value="a465a2791ae0bae853cf4bf485dbe1b6">
                                </form>
                            </div>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

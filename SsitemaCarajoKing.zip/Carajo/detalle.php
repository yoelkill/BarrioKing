<?php 
require_once 'php/controller/web.controller.php';
$controller = new webController();
$lista_detalle = call_user_func(array($controller,'lista_detalle'),$_REQUEST['pro']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<title>Eventos del Carajo</title>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<!-- SLIDE -->
	<link rel="stylesheet" type="text/css" href="css/navstylechange.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="css/settings.css" media="screen" />
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
</head>
<body style="background:black;"><form action="reservaciones.php" method="POST">
	

	<?php foreach ($lista_detalle as $row) { ?>

	<article class="boxedcontainer">

		<div class="tp-banner-container">
		    <div class="tp-banner" >
		        <ul>        		             
		        	<li data-transition="zoomin" data-slotamount="7" data-masterspeed="600" >
		        		<img src="img/evento/<?php echo $row->eve_foto2?>"  alt="videobg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">          
		        	</li>
		        	<li data-transition="zoomin" data-slotamount="7" data-masterspeed="600" >
		            	<img src="img/evento/<?php echo $row->eve_foto3?>"  alt="videobg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">          
		        	</li>
		        	<li data-transition="zoomin" data-slotamount="7" data-masterspeed="600" >
		        		<img src="img/evento/<?php echo $row->eve_foto4?>"  alt="videobg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">          
		        	</li>
		        </ul>
		        <div class="tp-bannertimer"></div>
		    </div>
	    </div>

	</article>
	<h1 class="text-center" style="color:white;">Descripcion del Evento</h1>

	<div class="container">
		<div class="row">
		
			<div class="col-xs-12 col-sm-12 col-md-12">
				<div class="panel panel-danger"> 
					<div class="panel-heading"> 
						<h3 class="panel-title"><?php echo $row->eve_titulo?></h3> 
					</div> 
					<div class="panel-body">
						<div class="col-xs-12 col-sm-12 col-md-6">							
							<img class="img-responsive center-block" src="img/evento/<?php echo $row->eve_foto1?>" alt="...">
							<div class="col-xs-12 col-sm-12 col-md-6">
								<h4><strong>Lugar:</strong> <span><?php echo $row->eve_lugar?></span></h4>
							</div>
							<div class="col-xs-12 col-sm-12 col-md-6"  >
<h4 ><strong >Fecha:</strong> <span  ><?php echo $row->eve_fecha ?></span></h4>
							</div> 
						</div>
						<div class="col-xs-12 col-sm-12 col-md-6">						
							<br>
							<?php echo $row->eve_cuerpo?>
							
							<a href="reservaciones.php?variable1=<?php echo $row->eve_fecha ?>" class="btn btn-danger btn-lg btn-block" role="button">Reservaciones</a>
						
						</div>						
						<br><br>
							
					</div> 
				</div>
			</div>
		<?php } ?>
			
		</div>
	</div>
	<br>
	<br>
	<br>
	<script src="js/bootstrap.min.js"></script>
	<!-- SLIDER REVOLUTION 4.x SCRIPTS  -->
    <script type="text/javascript" src="js/jquery.themepunch.tools.min.js"></script>
    <script type="text/javascript" src="js/jquery.themepunch.revolution.min.js"></script>

    <script type="text/javascript">

    var revapi;

    jQuery(document).ready(function() {

         revapi = jQuery('.tp-banner').revolution(
        {
          delay:9000,
          startwidth:1170,
          startheight:400,
          hideThumbs:10,
          fullWidth:"on",
          forceFullWidth:"on"
        });

    }); //ready

  </script>
 </form>
</body>
</html>
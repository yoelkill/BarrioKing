
<?php

session_start();
include_once 'php/util/dbconnect.php';


 $res=mysql_query("SELECT * FROM users WHERE user_id=".$_SESSION['user']);
    $userRow=mysql_fetch_array($res);

?>
	           
<!DOCTYPE HTML>
<HTML>

	<HEAD>
       <meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Reservaciones::Carajo</title>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="css/bootstrap-responsive.css">
		<script type="text/javascript" src="qrcode.js"></script> 
</HEAD>

	<BODY>

<br>
		<div class="container">
	        <div class="page-header">
	            <h1>Reserva de Asientos</h1>
	        </div>			
			<?php

					// check for a successful form post
					if (isset($_GET['s'])) 
					{
						echo "<div class=\"alert alert-success\">".$_GET['s']." Vas a ser Redireccionado en 3 seg.</div>";
//						echo "You will be automatically redirected after 5 seconds.";
						header("refresh: 3; index.php");
					}

					// check for a form error
					elseif (isset($_GET['e'])) echo "<div class=\"alert alert-error\">".$_GET['e']."</div>";

			?> 
			<form name="contactForm" action="register.php" method="POST" class="form-horizontal">
				<div class='control-group'>
					<label class='control-label' for='input1'>Numero de Asientos</label>
					<div class='controls'>
					<?php 
						for($i=1; $i<11; $i++)
						{
							$chparam = "ch" . strval($i);
							if(isset($_POST[$chparam]))
							{
								echo "<input type='text' class='span3' name=ch".$i." value=".$i." readonly/><br>";
							}
						}
					?>
	                </div>
	            </div>
	  
					<?php
					/*	if(isset($_POST['doj']))
						{*/
							echo "<div class='control-group'>";
							echo "<label class='control-label' for='input1'>Fecha del Evento</label>";
								echo "<div class='controls'>";
?>
									<input type='text' name='date' id='input1' class='span3' value= "<?php echo $_POST['doj'] ?>" readonly />
									<?php
								echo "</div>";
							echo "</div>";

						/*}*/
					
?>
				<div class="control-group">
	                <label class="control-label" for="input1">Nombre</label>
	                <div class="controls">
	                    <input type="text" name="user_name" id="input1" placeholder="Type your name" class="span3" pattern="[A-z ]{3,}" title="Please enter a valid name." value=" <?php echo $userRow['user_name']; ?>" required>
	               </div>
	            </div>
				
	            


	            <div class="control-group">
	                <label class="control-label" for="input5">Email </label>
	                <div class="controls">
	                    <input type="text" class="span3" placeholder="Type your email id" name="email"  title="Please enter a valid email id." value=" <?php echo $userRow['user_email']; ?>"required/>
	                </div>
	            </div>

	        

<div id="qrcode" class="controls">
<script type="text/javascript">
new QRCode(document.getElementById("qrcode"), " <?php echo $userRow['user_id']; ?>");
</script></div>


	            <div class="form-actions">
	                <input type="hidden" name="save" value="contact">
					<button type="submit" class="btn btn-info">
						<i class="icon-ok icon-white"></i> Confirmar
					</button>

					 <button type="reset" class="btn" >
						<i class="icon-refresh icon-black"></i> Limpiar
					</button>     
	            </div>

</form>


		<script src="http://code.jquery.com/jquery-latest.min.js"></script>
		<script>window.jQuery || document.write('<script src="js/jquery-latest.min.js">\x3C/script>')</script>
		<script type="text/javascript" src="js/bootstrap.js"></script>

		
	</BODY>
</HTML>